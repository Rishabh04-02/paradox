# paradox
-this repo will hold the paradox site designing
